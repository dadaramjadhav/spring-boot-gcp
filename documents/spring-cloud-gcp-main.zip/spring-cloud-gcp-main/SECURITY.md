# Security Policy

## Supported Versions

| Version | Supported          |
| ------- |--------------------|
| 3.x   | :heavy_check_mark: |
| 2.x   | :x:                |
| 1.x | :x:                |

## Reporting a Vulnerability

You can report any discovered vulnerabiltiies by visiting https://goo.gl/vulnz and learn more information at https://www.google.com/about/appsecurity/
